﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SSP_lab3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ComboBox_Selected(object sender, RoutedEventArgs e)
        {
            ComboBox comboBox = (ComboBox)sender;
            ComboBoxItem selectedItem = (ComboBoxItem)comboBox.SelectedItem;

            if (selectedItem.Content == null)
            {
                return;
            }

            this.Canvas.DefaultDrawingAttributes.Color = (Color)ColorConverter.ConvertFromString(selectedItem.Content.ToString());
        }

        private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            ((Slider)sender).SelectionEnd = e.NewValue;

            this.Canvas.DefaultDrawingAttributes.Width = e.NewValue;
            this.Canvas.DefaultDrawingAttributes.Height = e.NewValue;
        }

        private void DrawRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            this.Canvas.EditingMode = InkCanvasEditingMode.Ink;
        }

        private void EditRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            this.Canvas.EditingMode = InkCanvasEditingMode.Select;
        }

        private void DeleteRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            this.Canvas.EditingMode = InkCanvasEditingMode.EraseByStroke;
        }
    }
}
