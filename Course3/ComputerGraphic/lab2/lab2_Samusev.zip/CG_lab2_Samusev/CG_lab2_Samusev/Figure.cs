﻿namespace CG_lab2_Samusev
{
    class Figure
    {
        public Line[] Lines { get; set; }

        public Figure(Line[] lines)
        {
            Lines = lines;
        }
    }
}
